<div class="tw-ac-settings">
	<?php include "box/menu.php"?>

	<div class="tw-ac-stats">
		
		<div class="tw-ac-stats-items row ajax-load-stats" data-id="<?php _e( segment(4) )?>" data-page="0" data-load-type="scroll" data-scroll=".twitter-activity.content-one-column">

			<div class="fa-5x m-auto m-t-100">
			  <i class="fas fa-spinner fa-spin text-info"></i>
			</div>

		</div>

	</div>


</div>