<?php
use Abraham\TwitterOAuth\TwitterOAuth;
if(!class_exists("twac")){

	class twac{

		public function __construct($account = []){
			$this->activity = [];
	        $this->todo = false;
	        $this->number = 0;
            $this->username = $account->username;
	        $this->account = $account;
	        $this->watching_stories = [];
	        $this->follows = [];
	        $this->unfollows = [];
	        $this->comments = [];
	        $this->directs = [];
	        $this->reposts = null;
            $this->target = null;
	        $this->filters = [];
	        $this->blacklist_tags = [];
	        $this->blacklist_usernames = [];
	        $this->blacklist_keywords = [];
	        $this->data = null;
	        $this->ci = &get_instance();
	        $this->type = "feed";
	        $this->consumer_key = get_option('twitter_consumer_key', '') ;
        	$this->consumer_secret = get_option('twitter_consumer_secret', '');
	        
	        $this->twitter = new TwitterOAuth($this->consumer_key, $this->consumer_secret);
	        
	        $access_token = json_decode($account->token);
			$this->twitter->setOauthToken($access_token->oauth_token, $access_token->oauth_token_secret);
			$this->twitter->setTimeouts(10,60);
	    }

	    public function get_user_info($username = false){
            if(!$username){
            	return $this->twitter->get("account/verify_credentials");
            }else{

            }
        }

        public function search($type, $keyword){

            try {
                switch ($type) {

                    case 'username':
                        return $this->twitter->get( "users/search", [ "q" => $keyword, "count" => 20 ]);

                    default:
                        break;
                }
            } catch (Exception $e) {
                throw new Exception($e->getMessage());
            }
        }

        public function run($data){
            $field = false;

            $this->activity = json_decode($data->data, 0);
            $this->todo = $data->action;
            $this->filters = get_value($this->activity, "filters");
            $this->follows = get_value($this->activity, "follows");
            $this->unfollows = get_value($this->activity, "unfollows");
            $this->op_comments = get_value($this->activity, "op_comments");
            $this->comments = get_value($this->activity, "comments");
            $this->op_directs = get_value($this->activity, "op_directs");
            $this->directs = get_value($this->activity, "directs");
            $this->op_reposts = get_value($this->activity, "op_reposts");
            $this->reposts = get_value($this->activity, "reposts");
            $this->blacklist_tags = get_value($this->activity, "blacklist_tags");
            $this->blacklist_usernames = get_value($this->activity, "blacklist_usernames");
            $this->blacklist_keywords = get_value($this->activity, "blacklist_keywords");
            $this->data = $data;
            $this->number = $data->number;
            $this->type = "feed";

            if( !in_array( $this->todo, ["favorite", "reply", "retweet"]) ){
                $this->type = "user";
            }

            $target = $this->random_field("targets", false);
            $this->target = $target;

            if($this->todo != "unfollow"){
                $field = $this->target($target);
            }

            return $this->action($target, $field);
        }

        public function action($target, $field){
            switch ($this->todo) {
                case 'direct':
                    $data = 1;
                    break;

                case 'unfollow':
                    $source = $this->unfollows->source;
                    switch ($source) {
                        case 'db':
                            
                            $after_day = $this->unfollows->after; 
                            $after_day =  time() - $after_day*86400;
                            $data = $this->ci->model->get("id,user_id", "sp_twitter_activities_log", "action = 'follow' AND media_id IS NULL AND created < '{$after_day}' AND pid = '{$this->data->pid}'", "id", "desc");
                            break;
                        
                        default:
                            $data = $this->get_self_following();
                            break;
                    }

                    break;

                default:
                    $data = $this->get_data($target, $field);
                    break;
            }

            $status = "fail";
            if($data)
            {
                switch ($this->todo) {
                    case 'favorite':
                            $response = $this->twitter->post( "favorites/create", [ "id" => $data->id ] );
                            $this->error($response);
                            if(isset($response->id)){
                            	$status = "success";
                            }
                        break;

                    case 'reply':
                            $reply = $this->random_field("replies");
                            $response = $this->twitter->post( "statuses/update", [
                                "status" => "@".$data->user->screen_name." ".$reply,
                                "auto_populate_reply_metadata" => true,
                                "in_reply_to_status_id" => $data->id_str
                            ] );

                            $this->error($response);
                            if(isset($response->id)){
                                $status = "success";
                            }
                        break;

                    case 'retweet':
                            $response = $this->twitter->post( "statuses/retweet/".$data->id , [ "id" => $data->id ] );
                            $this->error($response);
                            if(isset($response->id)){
                                $status = "success";
                            }
                        break;

                    case 'direct':
                            $direct = $this->random_field("directs");


                            $last_follower = tw_get_setting("last_follower", "", $this->account->pid);
                            $follow_ids = $this->twitter->get("followers/list", ["id" => $this->account->account_id]);

                            if( isset($follow_ids->users) && isset($follow_ids->users[0]) && $follow_ids->users[0]->id != $last_follower){

                                $direct = str_replace("{username}", $follow_ids->users[0]->screen_name, $direct);
                                $direct = str_replace("{name}", $follow_ids->users[0]->name, $direct);

                                $data = [
                                    'event' => [
                                        'type' => 'message_create',
                                        'message_create' => [
                                            'target' => [
                                                'recipient_id' => $follow_ids->users[0]->id
                                            ],
                                            'message_data' => [
                                                'text' => $direct
                                            ]
                                        ]
                                    ]
                                ];

                                $response = $this->twitter->post( "direct_messages/events/new" , $data, true);

                                $this->error($response);
                                if(isset($response->id)){
                                    $status = "success";
                                }

                                $response = $follow_ids->users[0];

                                tw_update_setting("last_follower", $follow_ids->users[0]->id, $this->account->pid);
                            }else{
                                $response = false;
                            }
                            
                        break;

                    case 'follow':
                            $response = $this->twitter->post( "friendships/create", [ "screen_name" => $data->screen_name, "follow" => true ] );
                            $this->error($response);
                            if(isset($response->id)){
                                $status = "success";
                            }
                        break;

                    case 'unfollow':
                            $source = $this->unfollows->source;
                            switch ($source) {
                                case 'db':
                                    if($this->unfollows->dont_follower){
                                        $friendships = $this->twitter->get( "friendships/lookup", [ "screen_name" => $data->user_id ] );
                                        $this->error($friendships);
                                        if( !empty($friendships) && in_array("followed_by", $friendships[0]->connections) ){
                                            $response = $this->twitter->post( "friendships/destroy", [ "screen_name" => $data->user_id ] );
                                            $this->error($response);
                                            if(isset($response->id)){
                                                $status = "success";
                                                $this->ci->db->update("sp_twitter_activities_log", array("action" => "unfollow", "created" => time()), array("id" => $data->id ));
                                            }
                                        }else{
                                            $this->ci->db->update("sp_twitter_activities_log", array("media_id" => "1"), array("id" => $data->id ));
                                        }
                                    }else{
                                        $response = $this->twitter->post( "friendships/destroy", [ "screen_name" => $data->user_id ] );
                                        $this->error($response);
                                        if(isset($response->id)){
                                            $status = "success";
                                            $this->ci->db->update("sp_twitter_activities_log", array("action" => "unfollow", "created" => time()), array("id" => $data->id ));
                                        }
                                    }
                                    break;
                                
                                default:
                                    $response = $this->twitter->post( "friendships/destroy", [ "screen_name" => $data->screen_name ] );
                                    $this->error($response);
                                    if(isset($response->id)){
                                        $status = "success";
                                    }
                                    break;
                            }
                            
                        break;

                }

                return $response;
             
            }

            return false;
        }

        public function target($target){
            $value = false;
            $by = $this->random_field("targets");

            $this->random_field("targets");

            switch ($target) {
                case 'tag':
                    $value = trim( $this->random_field("tags") );
                    break;

                case 'keyword':
                    $value = trim( $this->random_field("keywords") );
                    break;

                case 'follower':
                    $value = $this->target_advance($by);
                    break;

                case 'following':
                    $value = $this->target_advance($by);
                    break;

                case 'retweeter':
                    $value = $this->target_advance($by);
                    break;
            }

            return $value;
        }

        public function target_advance( $by){
            $field = false;
            $rand = rand(1,2);
            if($by == "user" || ($by == "all" && $rand == 1)){
                $username = $this->random_field("usernames");
                $username = explode("|", $username);
                if(count($username) == 2){
                    $field = $username[1];
                }

                return $field;
            }else{
                $field = $this->username;
                return $field;
            }
        }

        public function filter($type, $data){
            $time_array = array("new" => 1800, "1h" => 3600, "12h" => 43200, "1d" => 86400, "3d" => 259000, "1w" => 604800, "2w" => 1209600, "1m" => 2419200);

            $ok = true;
            //Filter feed

            foreach ($data as $key => $row) {

                if($type = "feed"){

                    //Media Age
                    if( isset($this->filters->media_age) && array_key_exists($this->filters->media_age, $time_array) ){
                        $media_age = $this->filters->media_age;
                        if(time() - strtotime($row->created_at) > $time_array[$media_age]){ continue; }
                    }

                    if( isset($this->filters->min_like) && (int)$this->filters->min_like != 0 ){
                        $min_like = $this->filters->min_like;
                        if( $min_like > $row->favorite_count ){ continue; }
                    }

                    if( isset($this->filters->max_like) && (int)$this->filters->max_like != 0 ){
                        $max_like = $this->filters->max_like;
                        if( $max_like < $row->favorite_count ){ continue; }
                    }

                    if( isset($this->filters->min_retweet) && (int)$this->filters->min_retweet != 0 ){
                        $min_retweet = $this->filters->min_retweet;
                        if( $min_retweet > $row->retweet_count ){ continue; }
                    }

                    if( isset($this->filters->max_retweet)  && (int)$this->filters->max_retweet != 0){
                        $max_retweet = $this->filters->max_retweet;
                        if( $max_retweet < $row->retweet_count ){ continue; }
                    }
                }

                if(
                    (isset($this->filters->min_follower) && (int)$this->filters->min_follower != 0) ||
                    (isset($this->filters->max_follower) && (int)$this->filters->max_follower != 0) ||
                    (isset($this->filters->min_following) && (int)$this->filters->min_following != 0) ||
                    (isset($this->filters->max_following) && (int)$this->filters->max_following != 0) ||
                    isset($this->filters->user_profile) ||
                    isset($this->filters->user_relation)
                ){

                    if($type = "feed"){
                        $userinfo = $row->user;
                    }else{
                        $userinfo = $row;
                    }
                    
                    if(isset($this->filters->min_follower) && $this->filters->min_follower != 0 && $this->filters->min_follower > $userinfo->followers_count ){
                        continue;
                    }

                    if(isset($this->filters->max_follower) && $this->filters->max_follower != 0 && $this->filters->max_follower < $userinfo->followers_count ){
                        continue;
                    }

                    if(isset($this->filters->min_following) && $this->filters->min_following != 0 && $this->filters->min_following > $userinfo->friends_count ){
                        continue;
                    }

                    if(isset($this->filters->max_following) && $this->filters->max_following != 0 && $this->filters->max_following < $userinfo->friends_count ){
                        continue;
                    }

                    //User profile
                    if(isset($this->filters->user_profile)){
                        $user_profile = $this->filters->user_profile;
                        switch ($user_profile) {
                            case 'low':
                                if( $userinfo->profile_image_url != "" || $userinfo->statuses_count == 0){
                                    continue 2;
                                }
                                break;

                            case 'medium':
                                if( $userinfo->profile_image_url != "" || $userinfo->statuses_count < 10 || $userinfo->name == ""){
                                    continue 2;
                                }
                                break;
                            case 'high':
                                if( $userinfo->profile_image_url != "" || $userinfo->statuses_count < 30 || $userinfo->name == "" || $userinfo->gdescription == ""){
                                    continue 2;
                                }
                                break;
                        }
                    }

                }
                
                return $row;
            }

            return false;
        }

        public function blacklist($data){
            if(!empty($data)){
                foreach ($data as $key => $value) {
                    $ok = false;

                    //Tags
                    $caption = strtolower($value->text);
                    if(!empty($this->blacklist_tags) && !$ok){
                        foreach ($this->blacklist_tags as $tag) {
                            if (strpos($caption, "#".strtolower($tag)) !== false) {
                                unset($data[$key]);
                                $ok = true;
                                break;
                            }
                        }
                    }

                    //Keywords
                    if(!empty($this->blacklist_keywords) && !$ok){
                        foreach ($this->blacklist_keywords as $keyword) {
                            if (strpos($caption, strtolower($keyword)) !== false) {
                                unset($data[$key]);
                                $ok = true;
                                break;
                            }
                        }
                    }


                    //Username
                    $username = $value->user->screen_name;
                    if(!empty($this->blacklist_usernames) && !$ok){
                        foreach ($this->blacklist_usernames as $value) {
                            $value = explode("|", $value);
                            if(count($value) == 2){
                                if ($username == $value[1]) {
                                    unset($data[$key]);
                                    $ok = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            }

            if(!empty($data)){
                $data = array_values($data);
            }

            return $data;
        }

        public function get_feed_by_tag($tag){
        	$tag = str_replace("#", "", $tag);
        	$tag = "#".$tag;
            $items = $this->twitter->get("search/tweets", ["q" => $tag]);
            $this->error($items);
            $items = $items->statuses;
            $items = $this->dont_reply_same_users("feed", $items);
            $items = $this->dont_reply_same_posts($items);
            $items = $this->blacklist($items);
            if(!empty($items)){
                shuffle($items);
            }
            $item = $this->filter("feed", $items);
            return $item;
        }

        public function get_feed_by_keyword($keyword){
            $items = $this->twitter->get("search/tweets", ["q" =>  $keyword ]);
            $this->error($items);
            $items = $items->statuses;
            $items = $this->dont_reply_same_users("feed", $items);
            $items = $this->dont_reply_same_posts($items);
            $items = $this->blacklist($items);
            if(!empty($items)){
                shuffle($items);
            }
            $item = $this->filter("feed", $items);
            return $item;
        }

        public function get_feed_by_username($user_id){
            $items = $this->twitter->get("statuses/user_timeline", [
            	"screen_name" =>  $user_id,
            	"count" => 200
            ]);
            $this->error($items);
            $items = $this->dont_reply_same_users("feed", $items);
            $items = $this->dont_reply_same_posts($items);
            $items = $this->remove_empty_retweet($items);
            $items = $this->blacklist($items);
            if(!empty($items)){
                shuffle($items);
            }
            $item = $this->filter("feed", $items);
            return $item;
        }

        public function get_retweeters($tweet_id){
            $maxId = null;
            $items = $this->twitter->get( "statuses/retweets/".$tweet_id, [ "id" => $tweet_id ] );
            $this->error($items);
            if(!empty($items)){
                $index = array_rand($items);
                $result = $items[$index];
                return $result;
            }

            return false;
        }

        public function get_self_following(){
            $maxId = -1;
            $items = [];
            $data = [
                "screen_name" =>  $this->username, 
                "count" => 100, 
                "next_cursor" => $maxId
            ];

            $response = $this->twitter->get("friends/list", $data);
            $this->error($response);

            if( !empty( $response->users ) ){
                foreach ($response->users as $row) {
                    $items[] = $row;
                }
            }

            if(!empty($items)){
                foreach ($items as $key => $row) {
                    $username = $row->screen_name;
                    if(!empty($this->blacklist_usernames)){
                        foreach ($this->blacklist_usernames as $value) {
                            $value = explode("|", $value);
                            if(count($value) == 2){
                                if ($username == $value[1]) {
                                    unset($items[$key]);
                                    break;
                                }
                            }
                        }
                    }

                }
            }

            if($this->unfollows->dont_follower){
                $items = $this->remove_my_following($items);
            }

            if(!empty($items)){
                $index = array_rand($items);
                $result = $items[$index];
                return $result;
            }

            return false;
        }

        public function get_follower($user_id){
            $maxId = -1;
            $items = [];
        	$data = [
        		"screen_name" =>  $user_id, 
        		"count" => 100, 
        		"next_cursor" => $maxId
        	];

        	$response = $this->twitter->get("followers/list", $data);
        	$this->error($response);

            if( !empty( $response->users ) ){
                foreach ($response->users as $row) {
                    $items[] = $row;
                }
            }
            $items = $this->dont_reply_same_users("user", $items);
            $items = $this->remove_users_following("user", $items);
            $items = $this->dont_follow_same_users("user", $items);
            if(!empty($items)){
                
                do {
                    $index = array_rand($items);
                    $result = $items[$index];
                    if( $result->statuses_count != 0 ){
                        return $result;
                    }else{
                        unset($items[$index]);
                    }
                } while (!empty( $items ));
            }

            return false;
        }

        public function get_following($user_id){
            $maxId = -1;
            $items = [];
        	$data = [
        		"screen_name" =>  $user_id, 
        		"count" => 100, 
        		"next_cursor" => $maxId
        	];

        	$response = $this->twitter->get("friends/list", $data);
        	$this->error($response);

            if( !empty( $response->users ) ){
                foreach ($response->users as $row) {
                    $items[] = $row;
                }
            }

            $items = $this->dont_reply_same_users("user", $items);
            $items = $this->remove_users_following("user", $items);
            $items = $this->dont_follow_same_users("user", $items);
            if(!empty($items)){
                
                do {
                    $index = array_rand($items);
                    $result = $items[$index];
                    if( $result->statuses_count != 0 ){
                        return $result;
                    }else{
                        unset($items[$index]);
                    }
                } while (!empty( $items ));
            }

            return false;
        }

        public function remove_my_following($data){
            $users = [];
            if(!empty($data)){
                foreach ($data as $value) {
                    $users[] = $value->screen_name;
                }

                $users = implode(",", $users);

                $friendships = $this->twitter->get( "friendships/lookup", [ "screen_name" => $users ] );

                foreach ($friendships as $key => $value) {
                    if( in_array("followed_by", $value->connections) ){
                        $remove_items[] = $value->screen_name;
                    }
                }

                if(!empty($remove_items)){
                    foreach ($data as $key => $value) {
                        if( in_array($value->screen_name, $remove_items) ){
                            unset($data[$key]);
                        }
                    }
                }
            }

            if(!empty($data)){
                $data = array_values($data);
            }

            return $data;
        }

        //Don't comment same users
        public function dont_reply_same_users($type, $data){

            if($this->todo == "reply" && isset($this->op_replies->dont_spam) && !empty($data)){
                switch ($type) {
                    case 'feed':
                        $feeds_tmp = [];
                        foreach ($data as $key => $row) {
                            $item = $this->ci->model->get("id", "sp_twitter_activities_log", "user_id = '{$row->user->screen_name}' AND action = 'reply' AND pid = '{$this->data->pid}'");
                            if(empty($item)) $feeds_tmp[] = $row;
                        }
                        $data = $feeds_tmp;
                        break;
                    
                    case 'user':
                        $users_tmp = [];
                        foreach ($data as $key => $row) {
                            $item = $this->ci->model->get("id", "sp_twitter_activities_log", "user_id = '{$row->screen_name}' AND action = 'reply' AND pid = '{$this->data->pid}'");
                            if(empty($item)) $users_tmp[] = $row;
                        }
                        $data = $users_tmp;
                        break;
                }

                if(!empty($data)){
                    $data = array_values($data);
                }
            }

            return $data;
        }

        //Don't send reply same posts
        public function dont_reply_same_posts($data){
            if($this->todo == "reply"){
                $feeds_tmp = [];
                if(!empty($data)){
                    foreach ($data as $key => $row) {
                        $item = $this->ci->model->get("id", "sp_twitter_activities_log", "media_id = '".$row->id."' AND action = 'reply' AND pid = '{$this->data->pid}'");
                        if(empty($item)) $feeds_tmp[] = $row;
                    }
                }
                $data = $feeds_tmp;
                
                if(!empty($data)){
                    $data = array_values($data);
                }
            }

            return $data;
        }

        public function remove_users_following($type, $data){
            if($this->todo == "follow"){
                $users = [];
                if($data){

                    foreach ($data as $value) {
                        switch ($type) {
                            case 'feed':
                                    $users[] = $value->user->screen_name;
                                break;
                            
                            case 'user':
                                    $users[] = $value->screen_name;
                                break;
                        }
                    }

                    $users = explode(",", $users);

                    $friendships = $this->twitter->get( "friendships/lookup", [ "screen_name" => explode(",", $users) ] );

                    $remove_items = [];
                    $friendships = $friendships->getFriendshipStatuses();
                    $friendships = json_decode( json_encode( $friendships ) );

                    foreach ($friendships as $key => $value) {
                        if( $value->following == 1 || $value->outgoing_request == 1 ){
                            $remove_items[] = $key;
                        }
                    }

                    foreach ($data as $key => $value) {
                        switch ($type) {
                            case 'feed':
                                $user_id = $value->getUser()->getPk();
                                break;
                            
                            default:
                                $user_id = $value->getPk();
                                break;
                        }

                        if( in_array($user_id, $remove_items) ){
                            unset($data[$key]); continue;
                        }
                    }

                }


                if(!empty($data)){
                    $data = array_values($data);
                }
            }

            return $data;
   
        }

        //Don't follow same users
        public function dont_follow_same_users($type, $data){
            if($this->todo == "follow" && isset($this->follows->dont_spam)){
                switch ($type) {
                    case 'feed':
                        $feeds_tmp = array();
                        if(!empty($data)){
                            foreach ($data as $key => $row) {
                                $item = $this->ci->model->get("id", "sp_twitter_activities_log", "user_id = '".$row->user->screen_name."' AND ( action = 'follow' OR action = 'unfollow' ) AND pid = '{$this->data->pid}'");
                                if(empty($item)) $feeds_tmp[] = $row;
                            }
                        }
                        $data = $feeds_tmp;
                        break;
                    
                    case 'user':
                        $users_tmp = array();
                        if(!empty($data)){
                            foreach ($data as $key => $row) {
                                $item = $this->ci->model->get("id", "sp_twitter_activities_log", "user_id = '".$row->screen_name."' AND ( action = 'follow' OR action = 'unfollow' ) AND pid = '{$this->data->pid}'");
                                if(empty($item)) $users_tmp[] = $row;
                            }
                        }
                        $data = $users_tmp;
                        break;
                }
            }

            return $data;
        }

        public function remove_empty_retweet($data){
            if(!empty($data) && $this->target == "retweeter"){
                foreach ($data as $key => $value) {
                    if( $value->retweet_count == 0 ){
                        unset($data[$key]);
                    }
                }
                $data = array_values($data);
            }

            return $data;
        }

        public function get_data($target, $value){

            $data = false;
            switch ($target) {
                case 'tag':
                    $data = $this->get_feed_by_tag($value);
                    if($this->type == "user"){
                        $data = $data->user;
                    }
                    break;

                case 'keyword':
                    $data = $this->get_feed_by_keyword($value);
                    if($this->type == "user"){
                        $data = $data->user;
                    }
                    break;

                case 'follower':
                    $item = $this->get_follower($value);
                    if($item){
                        if($this->type == "user"){
                            $data = $item;
                        }else{
                            $user_id = $item->screen_name;
                            $data = $this->get_feed_by_username($user_id);
                        }
                    }
                    break;

                case 'following':
                    $item = $this->get_following($value);
                    if($item){
                        if($this->type == "user"){
                            $data = $item;
                        }else{
                            $user_id = $item->screen_name;
                            $data = $this->get_feed_by_username($user_id);
                        }
                    }
                    break;

                case 'retweeter':
                    $item = $this->get_feed_by_username($value);
                    if($item){
                        $data = $this->get_retweeters($item->id);
                        if($this->type == "user"){
                            $data = $data->user;
                        }
                    }
                    break;

            }

            return $data;
        }

        public function error($data){
        	if( isset($data->errors) ){
            	throw new Exception( $data->errors[0]->message );
            }
        }

        public function random_field($field, $return_value = true){
            $data = get_value($this->activity, $field, true);
            $rand_key = array_rand($data);
            if(!empty($data)){
                if($return_value){
                    return $data[$rand_key];
                }else{
                    return $rand_key;
                }
            }
            return false;
        }

	}

}