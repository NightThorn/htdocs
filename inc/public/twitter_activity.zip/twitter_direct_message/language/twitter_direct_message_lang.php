<?php
$lang["Twitter Inbox"] = "Twitter Inbox";
$lang["Inbox"] = "Inbox";
$lang["Twitter"] = "Twitter";
$lang["Cannot send the message"] = "Cannot send the message";
$lang["Cannot delete this message"] = "Cannot delete this message";
$lang["Enter keyword"] = "Enter keyword";
$lang["Select an account"] = "Select an account";
$lang["Select your account"] = "Select your account";
$lang["Search"] = "Search";
$lang["Message..."] = "Message...";
