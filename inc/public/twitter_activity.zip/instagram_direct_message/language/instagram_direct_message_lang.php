<?php
$lang["Instagram Direct Message"] = "Instagram Direct Message";
$lang["Direct Message"] = "Direct Message";
$lang["Instagram"] = "Instagram";
$lang["Cannot send the messa"] = "Cannot send the messa";
$lang["Cannot delete this message"] = "Cannot delete this message";
$lang["Cannot hide this message"] = "Cannot hide this message";
$lang["There is a problem with your account please try again later"] = "There is a problem with your account please try again later";
$lang["Enter keyword"] = "Enter keyword";
$lang["Select an account"] = "Select an account";
$lang["Select your account"] = "Select your account";
$lang["Search"] = "Search";
$lang["Profile"] = "Profile";
$lang["Message..."] = "Message...";
$lang["Search instagram user"] = "Search instagram user";
$lang["Hide"] = "Hide";
$lang["New message"] = "New message";