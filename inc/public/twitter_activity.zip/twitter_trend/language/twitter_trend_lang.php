<?php
$lang["Success"] = "Success";
$lang["Top Twitter trends for %s"] = "Top Twitter trends for %s";
$lang["#"] = "#";
$lang["Name"] = "Name";
$lang["Volume"] = "Volume";
$lang["Trend"] = "Trend";